# For Röthzen — Birthday Scrapbook

A mobile-friendly birthday website made with plain HTML, CSS, and JavaScript. It can be hosted on GitHub Pages.

## Preview locally
Open `index.html` in a browser. For the best experience, use a simple local server or GitHub Pages so relative asset paths behave consistently.

## Personalize it

### 1. Add photographs
Put your selected images in `assets/photos/`. Then edit the photo cards in `index.html`:
- Replace each placeholder `<div class="photo-placeholder ...">...</div>` with an image, for example:
  `<img class="actual-photo" src="assets/photos/photo-01.jpg" alt="A short description">`
- Update the caption in the nearby `<p class="photo-caption">`.
- If you add an image to the hero card, replace its placeholder with an `<img>` and give it the `hero-photo` class.

For privacy, only use photos you have permission to share. GitHub Pages sites are public unless you take additional measures.

### 2. Add your song
Place a suitable audio file at `assets/music/birthday-song.mp3`, then open `script.js` and set:
`audioSource: "assets/music/birthday-song.mp3",`
Set `songLabel` to the title or a short label. The player waits for the visitor to press play. Use audio you have the right to upload and share; a streaming page URL usually cannot be used as an audio file.

### 3. Personalize the letters
Search `index.html` for bracketed prompts such as `[add your inside joke or playful detail here]` and replace them with your own words. The final letter is available from the navigation at any time.

### 4. Personalize the digital gifts
Edit the `CUSTOMIZE.gifts` text near the top of `script.js`. Each gift can be opened again after closing it.

### 5. Change decorative details
The current design uses a paper, blush, rose, and cherry-red palette. Colors are CSS variables at the top of `style.css`.

## Publish with GitHub Pages
1. Create a new GitHub repository, for example `rothzen-birthday`.
2. Upload `index.html`, `style.css`, `script.js`, and the `assets` folder to the repository root.
3. Open the repository's **Settings → Pages**.
4. Under the build/deployment source, select **Deploy from a branch**, choose `main` and `/(root)`, then save.
5. Wait for GitHub Pages to publish the site. The URL will appear in the Pages settings.

## Privacy note
A public GitHub Pages website is visible to anyone with the link and its files can be inspected. Do not put private information, passwords, or anything you would not want publicly accessible on the site. A client-side password screen would not make the content truly private.
