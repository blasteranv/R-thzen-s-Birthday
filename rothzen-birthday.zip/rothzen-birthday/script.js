// For Röthzen — edit the CUSTOMIZE section below to personalize the scrapbook.
const CUSTOMIZE = {
  // Put your audio file at assets/music/birthday-song.mp3, then keep this path,
  // or replace it with a direct URL to an audio file you have permission to use.
  audioSource: "",
  songLabel: "our song",
  gifts: {
    compliment: {
      label: "A LITTLE COMPLIMENT",
      title: "One of my favourite things about you.",
      text: "[Replace this with the quality you admire about Röthzen, and why it means something to you.]"
    },
    laugh: {
      label: "A TINY BIT OF NONSENSE",
      title: "A very serious message.",
      text: "[Put your inside joke or playful detail here. It can be silly. It is allowed to be extremely silly.]"
    },
    song: {
      label: "A SONG, JUST FOR YOU",
      title: "Press play when you're ready.",
      text: "[Add the song title, artist, and a sentence about why you chose it. Add your audio file to the music folder to enable playback.]"
    },
    extra: {
      label: "ONE MORE THING",
      title: "A little wish for you.",
      text: "I hope this year brings you quiet comfort, unexpected good news, people who show up for you, and plenty of days that feel like yours."
    }
  }
};

const intro = document.getElementById("intro");
const openEnvelopeButton = document.getElementById("open-envelope");
const scrapbook = document.getElementById("scrapbook");
const pages = [...document.querySelectorAll("[data-page]")];
const navButtons = [...document.querySelectorAll("[data-nav]")];
const toast = document.getElementById("toast");
const audio = document.getElementById("birthday-audio");
const musicToggle = document.getElementById("music-toggle");
const musicLabel = document.getElementById("music-label");
let toastTimer;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

function openScrapbook() {
  intro.querySelector(".intro-card").classList.add("opening");
  openEnvelopeButton.disabled = true;
  window.setTimeout(() => {
    intro.classList.add("hidden");
    scrapbook.classList.remove("hidden");
    showPage("home");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, 620);
}
openEnvelopeButton.addEventListener("click", openScrapbook);

function showPage(pageName) {
  const target = document.querySelector(`[data-page="${pageName}"]`);
  if (!target) return;
  pages.forEach(page => page.classList.toggle("active-page", page === target));
  document.querySelectorAll(".nav-link").forEach(button => {
    const active = button.dataset.nav === pageName;
    button.classList.toggle("active", active);
    if (active) button.setAttribute("aria-current", "page");
    else button.removeAttribute("aria-current");
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

navButtons.forEach(button => {
  button.addEventListener("click", () => {
    const destination = button.dataset.nav;
    if (!destination) return;
    showPage(destination);
  });
});

// Hidden letters: each note can be opened and closed independently.
document.querySelectorAll("[data-letter]").forEach(button => {
  button.addEventListener("click", () => {
    const content = document.getElementById(`letter-${button.dataset.letter}`);
    const willOpen = content.hidden;
    content.hidden = !willOpen;
    button.setAttribute("aria-expanded", String(willOpen));
    button.querySelector(".letter-chevron").textContent = willOpen ? "−" : "＋";
  });
});

// Gift boxes can be reopened at any time.
const giftReveal = document.getElementById("gift-reveal");
const giftRevealLabel = document.getElementById("gift-reveal-label");
const giftRevealTitle = document.getElementById("gift-reveal-title");
const giftRevealText = document.getElementById("gift-reveal-text");
document.querySelectorAll("[data-gift]").forEach(button => {
  button.addEventListener("click", () => {
    const gift = CUSTOMIZE.gifts[button.dataset.gift];
    if (!gift) return;
    document.querySelectorAll("[data-gift]").forEach(box => box.setAttribute("aria-expanded", String(box === button)));
    giftRevealLabel.textContent = gift.label;
    giftRevealTitle.textContent = gift.title;
    giftRevealText.textContent = gift.text;
    giftReveal.hidden = false;
    giftReveal.scrollIntoView({ behavior: "smooth", block: "nearest" });
  });
});
document.getElementById("close-gift").addEventListener("click", () => {
  giftReveal.hidden = true;
  document.querySelectorAll("[data-gift]").forEach(box => box.setAttribute("aria-expanded", "false"));
});

// Audio is intentionally user-initiated; no autoplay.
function setMusicButton(isPlaying) {
  musicLabel.textContent = CUSTOMIZE.songLabel;
  musicToggle.setAttribute("aria-label", isPlaying ? "Pause birthday song" : "Play birthday song");
  musicToggle.title = isPlaying ? "Pause birthday song" : "Play birthday song";
  musicToggle.querySelector(".music-status").textContent = isPlaying ? "Ⅱ" : "·";
}
musicLabel.textContent = CUSTOMIZE.songLabel;
musicToggle.addEventListener("click", async () => {
  const source = CUSTOMIZE.audioSource.trim();
  if (!source) {
    showToast("Add your song file in script.js to turn the music on.");
    return;
  }
  if (audio.src !== new URL(source, window.location.href).href) audio.src = source;
  try {
    if (audio.paused) {
      await audio.play();
      setMusicButton(true);
    } else {
      audio.pause();
      setMusicButton(false);
    }
  } catch {
    showToast("The song could not play. Check the audio file path.");
  }
});
audio.addEventListener("ended", () => setMusicButton(false));
audio.addEventListener("pause", () => setMusicButton(false));
audio.addEventListener("play", () => setMusicButton(true));

// Placeholder photo cards are keyboard-accessible and explain how to personalize them.
document.querySelectorAll(".photo-card").forEach(card => {
  const explain = () => showToast("Replace this frame with one of your photos in index.html.");
  card.addEventListener("click", explain);
  card.addEventListener("keydown", event => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      explain();
    }
  });
});
