Optional decorative SVGs can be placed here. Current decorations are drawn with CSS and text symbols.
