Place your chosen photos in this folder, then add their paths to index.html.
