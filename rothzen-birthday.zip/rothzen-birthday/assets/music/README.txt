Place a suitable audio file here (for example birthday-song.mp3), then set audioSource in script.js.
